//only chrome
mvn -DtestngFileName=chrome.xml test
//only ff
mvn -DtestngFileName=firefox.xml test
mvn -DtestngFileName=crossbrowser.xml test
mvn -DtestngFileName=crossbrowserparallel.xml test
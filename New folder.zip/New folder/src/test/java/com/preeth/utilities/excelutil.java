package com.preeth.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelutil {

	public static String getvalue1() throws IOException {

		File src = new File("src/test/java/com/hellofresh/utilities/testdata.xlsx");
		FileInputStream fis = new FileInputStream(src);
		@SuppressWarnings("resource")
		XSSFWorkbook workbbook=new XSSFWorkbook(fis);
		XSSFSheet sheet1 = workbbook.getSheetAt(0);
		String testdata = sheet1.getRow(0).getCell(0).getStringCellValue();
		return testdata;
	}
	
}

/**
 * @author priyatham.bolli
 */
//public class excelutil {
//
//	public static XSSFWorkbook wb;
//	public static XSSFSheet sheet;
//	public static String cellValue;
//
//	public excelutil(String excelPath) {
//		try {
//			FileInputStream fis = new FileInputStream(excelPath);
//
//			wb = new XSSFWorkbook(fis);
//		} catch (Exception e) {
//			System.out.println("Excel Exception" + e.getMessage());
//		}
//	}
//
//	public String GetData(String sheetName, int rowNumber, int columnNumber) {
//		sheet = wb.getSheet(sheetName);
//
//		DataFormatter formatter = new DataFormatter();
//
//		cellValue = formatter.formatCellValue(sheet.getRow(rowNumber).getCell(columnNumber));
//
//		return cellValue;
//	}
//
////	public static void main(String[] args) {
////		excelutil excel = new excelutil("src/test/java/com/preeth/utilities/testdata.xlsx");
////		System.out.println(excel.GetData("Sheet1", 0, 0));
////	}
//
//}